/// <reference types="webxr" />
import { StreamMessageController } from '../UeInstanceMessage/StreamMessageController';
import { Controller } from './GamepadTypes';
/**
 * The class that handles the functionality of xrgamepads and controllers
 */
export declare class XRGamepadController {
    controllers: Array<Controller>;
    toStreamerMessagesProvider: StreamMessageController;
    /**
     * @param toStreamerMessagesProvider - Stream message instance
     */
    constructor(toStreamerMessagesProvider: StreamMessageController);
    /**
     * Deep copies a gamepad's values by first converting it to a JSON object and then back to a gamepad
     *
     * @param gamepad the original gamepad
     * @returns a new gamepad object, populated with the original gamepads values
     */
    static deepCopyGamepad(gamepad: Gamepad): Gamepad;
    updateStatus(source: XRInputSource, frame: XRFrame, refSpace: XRReferenceSpace): void;
}
